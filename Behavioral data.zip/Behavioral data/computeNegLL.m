function negLL = computeNegLL(phi,param);
%function computes negLogLikelihood(data,parameters) for BCI model, for use in fminsearch %%%% 

iModel = param.iModel;
rADistrib = param.rADistrib;
rVDistrib = param.rVDistrib;
iSubj = param.iSubj;
varFitA = param.varFitA;
varFitV = param.varFitV;

negLL = 0; % negative log likelihood which is to minimize
if iModel < 4;                                                                  %pComm  ,muP   ,sigmP ,sigA  ,sigV
    [pM_A,pM_V,pC1_givSASV] = computeRespDistrib(phi(1),phi(2),phi(3),phi(4),phi(5),param);%[iPCom(:),iMuP(:),iSigP(:),iSigA(:),iSigV(:)];
elseif iModel == 4;
    % pCommon = 1 fixed
    [pM_A,pM_V,pC1_givSASV] = computeRespDistrib( 1     ,phi(1),phi(2),phi(3),phi(4),param);%[iMuP(:),iSigP(:),iSigA(:),iSigV(:)];
elseif iModel == 5;%unimodel V
    [pM_A,pM_V,pC1_givSASV] = computeRespDistrib( 0     ,phi(1),phi(2),NaN   ,phi(3),param);%[iMuP(:),iSigP(:),iSigV(:)];         
elseif iModel == 6;%unimodal A
    [pM_A,pM_V,pC1_givSASV] = computeRespDistrib( 0     ,phi(1),phi(2),phi(3),NaN,param);%[iMuP(:), iSigP(:),iSigA(:)];   
elseif iModel == 7;%segregation
    % pCommon = 0 fixed
    [pM_A,pM_V,pC1_givSASV] = computeRespDistrib( 0     ,phi(1),phi(2),phi(3),phi(4),param);   %[iMuP(:),iSigP(:),iSigA(:),iSigV(:)];  
end;

% compute likelihood of multinomial distrib of A localization responses in a given condition
negLL = 0;
if varFitA == 1;
    LLCondRA  = sum(log(mnpdf(rADistrib(:,:,iSubj),pM_A))); % log likelihood of data under assumed multinomial distribution (resulting from model output p(sAHat | sA, sV))
    negLL = negLL - LLCondRA;
end;
if varFitV == 1;
    LLCondRV  = sum(log(mnpdf(rVDistrib(:,:,iSubj),pM_V))); % log likelihood of data under assumed multinomial distribution (resulting from model output p(sAHat | sA, sV))
    negLL = negLL - LLCondRV;
end;