function [] = fitCausalInferenceModel();
% fitting Kording et al. (2007) 's model with maximum likelihood estimation to
% auditory and visual counting reports which were published in Rohe, Ehlis, Noppeney (2018) �The neural dynamics of causal inference in perception�.
% The decision functions "model selection" and "probability matching" were
% first described in Wozny et al. (2010).
% Please cite accordingly when using this data or function.
% Free model parameters: Causal prior pCommon, numerical prior's mean muP, numerical prior's STD sigmaP, auditory sensory STD sigmaA, visual sensory STD sigmaV 
% Citations:
% Kording, K. P. et al. Causal inference in multisensory perception. PloS one 2, e943, doi:10.1371/journal.pone.0000943 (2007).
% Wozny, D. R., Beierholm, U. R. & Shams, L. Probability matching as a computational strategy used in perception. PLoS Comput Biol 6, doi:10.1371/journal.pcbi.1000871e1000871 [pii] (2010).


%load data:
%  KoerdingBehavInput_N=49
%  vs. KoerdingBehavInput_N=49_ControlSubsampled
dataPath = 'E:\Users\Tim\PostDoc\Experiments\Exp1_DoubleFlash_McGurk\Paper\Manuscript\Nature Communications\Revision 1\Dryad\BehavioralDataAndModelFit\BehavioralData.mat';
load(dataPath,'BehavioralDat');
% stimulus parameters
cueSpace = [1:4]; % number of stimuli in the experiment
sSpaceTmp(1,1,1:4) = cueSpace;
fitParam.sSpace = sSpaceTmp; % fitParam is a structure of parameters which are needed inside functions which are to optimize

% parameter output path 
sep = strfind(dataPath,'\');
parameterPath = [dataPath(1:sep(end)) 'modelData\'];
if ~exist(parameterPath);
    mkdir(parameterPath);
end;

%--- choose target data to which model is fitted (e.g. auditory report or visual report or both) ---
fitParam.varFitA = 1; % fit to A counting (1 yes 0 no)
fitParam.varFitV = 1;% fit to V counting


% paramters for fitting
maxSigm = 15; % maximum sigma which any of the distributions can take
noRunsMax = 10; % 100 number of runs each starting with different parameter values
maxFunEvals = 2000; % 300
fitParam.noSimTrials = 5000;
options = optimset('MaxFunEvals',maxFunEvals,'Display','on','FunValCheck','on');
% which models to fit
% models types:  model 1 = model averaging; = 2  model selection; = 3 probability
% matching; = 4 forced fusion; = 5 = unimodelVisual; = 6 = unimodalAuditory;
% = 7 segregation model with pure report of task-relevant and segregation of
% task irrelevant signal
modelNames = {'ModelAveraging','ModelSelection','ProbabilityMatching','ForcedFusion','unimodelVisual','unimodalAuditory','fullSegregation'};
models = 1:7;

% code data
modality = BehavioralDat.modality;
%restrict fitting to audiovisual conditions and trials with a valid response (missed response is NaN)
avInd = modality == 1 & ~isnan(BehavioralDat.countingReport);
subjInd = BehavioralDat.subject(avInd);
subj = unique(subjInd)';
noSubj = length(subj);
task = BehavioralDat.task(avInd);
nA = BehavioralDat.nA(avInd);
nV = BehavioralDat.nV(avInd);
report = BehavioralDat.countingReport(avInd);



%--- combinatorically combine conditions of sA,sV and vRel
[sA,sV] = ndgrid(unique(round(nA)),unique(round(nV)));
noCond = prod(size(sA));
conditions = [sA(1:end)',sV(1:end)'];
fitParam.sA = sA;
fitParam.sV = sV;

% precompute variables which are used in optimization later: expand sA, sV, pComon sigV , i.e. variables which change across trials
fitParam.sA = repmat(conditions(:,1),[1,fitParam.noSimTrials]);
fitParam.sV = repmat(conditions(:,2),[1,fitParam.noSimTrials]);

fitParam.xAPre = randn(noCond,fitParam.noSimTrials);
fitParam.xVPre = randn(noCond,fitParam.noSimTrials);

% compute response distributions of auditory and visual counting reports for each condition in each subject
indT1 = task == 1;
indT2 = task == 2;
if fitParam.varFitA == 1;
    rADistrib = crosstab(nA(indT1),nV(indT1),report(indT1),subjInd(indT1));
    rADistrib = reshape(rADistrib,noCond,length(cueSpace),length(subj)); % dim1 = conditions, dim2 = 5 buttons, dim3 = subjects
    rADistribOverall = squeeze(sum(rADistrib,1))';
    fitParam.rADistrib = rADistrib;
    if noSubj == 1;
        rADistribOverall = rADistribOverall';        
    end;
    nTrialsSubjRA = sum(rADistribOverall,2);
end;
if fitParam.varFitV == 1;
    rVDistrib = crosstab(nA(indT2),nV(indT2),report(indT2),subjInd(indT2));
    rVDistrib = reshape(rVDistrib,noCond,length(cueSpace),length(subj)); % dim1 = conditions, dim2 = 5 buttons, dim3 = subjects
    rVDistribOverall =  squeeze(sum(rVDistrib,1))';
    fitParam.rVDistrib = rVDistrib;
    if noSubj == 1;
        rVDistribOverall = rVDistribOverall';        
    end;
    nTrialsSubjRV = sum(rVDistribOverall,2);
end;

% compute likelihood of 0 model (which is represented by response distribution over all conditions, assuming no difference between conditions)
LL0ModelSubj = zeros(noSubj,1);
noPhi0ModelSubj = zeros(noSubj,1);
nTrialsSubj = zeros(noSubj,1);
for iSubj = subj;   
    if fitParam.varFitA == 1;        
        nTrialsSubj(iSubj) = nTrialsSubj(iSubj) + nTrialsSubjRA(iSubj);
        LLRA0ModelSubj(iSubj,1)  = sum(log(mnpdf(rADistrib(:,:,iSubj),ones(1,length(cueSpace))*1/length(cueSpace)))); 
        LL0ModelSubj(iSubj,1) =  LL0ModelSubj(iSubj,1) + LLRA0ModelSubj(iSubj,1); 
    end;
    if fitParam.varFitV == 1;
        nTrialsSubj(iSubj) = nTrialsSubj(iSubj) + nTrialsSubjRV(iSubj);
        LLRV0ModelSubj(iSubj,1)  = sum(log(mnpdf(rVDistrib(:,:,iSubj),ones(1,length(cueSpace))*1/length(cueSpace)))); 
        LL0ModelSubj(iSubj,1) =  LL0ModelSubj(iSubj,1) + LLRV0ModelSubj(iSubj,1); 
    end;
end;
nTrials = sum(nTrialsSubj);

%--- define parameter space for initial grid search
nSteps = 6;
initMuPSpace = [1:4/nSteps:4];
initSigSpace = [0.1:(maxSigm*0.75)/(nSteps-1):0.9*maxSigm];
initPComSpace = [0.01:0.8/(nSteps-1):0.99];


% initialize variables
phiRuns = NaN(noRunsMax,5,max(subj),max(models)); % dim1  = Runs, dim2 = CI model parameters 1-5, dim3 = subjects, dim4 = model
negLLRuns = NaN(noRunsMax,max(subj),max(models)); % dim1 = runs , dim2 = subject, dim3 = model
subjBestPhi = NaN(max(subj),5,max(models)); % dim1 = subject number, dim2 = CI model parameters 1-5, dim3 = model
LLModelSubj = NaN(max(subj),max(models));% dim1 = subject number, dim2 = model 
maxRSquSubj = NaN(max(subj),max(models));% dim1 = subject number, dim2 = model 
rSquSubj = NaN(max(subj),max(models));% dim1 = subject number, dim2 = model 
rSquCorrSubj = NaN(max(subj),max(models));% dim1 = subject number, dim2 = model 
BIC = NaN(max(subj),max(models));% dim1 = subject number, dim2 = model 
AIC = NaN(max(subj),max(models));% dim1 = subject number, dim2 = model 
    
for iModel = [1:7];
    
    fitParam.iModel = iModel;
    
    if iModel < 4;
        [iPCom iMuP iSigP  iSigA iSigV ] = ndgrid(initPComSpace,initMuPSpace,initSigSpace,initSigSpace,...
        initSigSpace);
        nGridPts = prod(size(iPCom));
        gridPhi = [iPCom(:),iMuP(:),iSigP(:),iSigA(:),iSigV(:)];
        lowerBoundPhi = [ 0.01 1 zeros(1,3)  ];
        upperBoundPhi = [ 0.99 4 ones(1,3) * maxSigm];
    elseif iModel == 4;%FF
        [iMuP iSigP iSigA iSigV ] = ndgrid(initMuPSpace,initSigSpace,initSigSpace,initSigSpace);
        nGridPts = prod(size(iSigP));
        gridPhi = [iMuP(:),iSigP(:),iSigA(:),iSigV(:)];
        lowerBoundPhi = [1 zeros(1,3)  ];
        upperBoundPhi = [4 ones(1,3) * maxSigm];  
    elseif iModel == 5;%uniV
        [iMuP iSigP iSigV ] = ndgrid(initMuPSpace,initSigSpace,initSigSpace);
        nGridPts = prod(size(iSigP));
        gridPhi = [iMuP(:),iSigP(:),iSigV(:)];         
        lowerBoundPhi = [1 0 0  ];
        upperBoundPhi = [4 ones(1,2) * maxSigm];        
    elseif iModel == 6;%uniA
        [iMuP iSigP iSigA ] = ndgrid(initMuPSpace,initSigSpace,initSigSpace);
        nGridPts = prod(size(iSigP));
        gridPhi = [iMuP(:), iSigP(:),iSigA(:)];        
        lowerBoundPhi = [1 0 0 ];
        upperBoundPhi = [4 ones(1,2) * maxSigm];   
    elseif iModel == 7; %segregation
        [iMuP iSigP iSigA iSigV ] = ndgrid(initMuPSpace,initSigSpace,initSigSpace,initSigSpace);
        nGridPts = prod(size(iSigP));
        gridPhi = [iMuP(:),iSigP(:),iSigA(:),iSigV(:)];
        lowerBoundPhi = [1 zeros(1,3)  ];
        upperBoundPhi = [4 ones(1,3) * maxSigm];        
    end;
     
   
    for iSubj = subj;  
        
        fitParam.iSubj = iSubj;           
           
        % initial grid search
        negLLGrid = NaN(nGridPts,1);
        for iGridPt = 1:nGridPts;            
            phi = gridPhi(iGridPt,:);
            negLL = computeNegLL(phi,fitParam);           
            negLLGrid(iGridPt,1) = negLL;
        end;
        [~, sortInd] = sort(negLLGrid,1,'ascend');
        
        noRuns = min([noRunsMax,nGridPts]);
        for iRuns = 1:noRuns;
            [iModel,iSubj,iRuns]            
            phi = gridPhi(sortInd(iRuns),:);  
            noPhi(iSubj,iModel) = length(phi(isfinite(phi)));    
             
            [phiML,negLLMin] = fminsearchbnd(@(phi2) computeNegLL(phi2,fitParam),phi,lowerBoundPhi,upperBoundPhi,options);
            % parameters:  %pComm  ,muP   ,sigmP ,sigA  ,sigV
            if iModel == 4; % FF
                phiML = [1 phiML];
            elseif iModel == 5; % uniV
                phiML = [NaN,phiML(1:2),NaN,phiML(3)];
            elseif iModel == 6;% uniA
                phiML = [NaN,phiML(1:3),NaN];
            elseif iModel == 7;
                phiML = [0 phiML];
            end;            
            phiRuns(iRuns,1:5,iSubj,iModel) = phiML;
            negLLRuns(iRuns,iSubj,iModel) = negLLMin;
         
        end;        
        
        try
            save(parameterPath);  
        catch
        end;   
    end;
   
    negLLRuns(negLLRuns == 0) = inf;
    [minLL minInd] = min(negLLRuns(:,:,iModel),[],1);
    LLModelSubj(:,iModel) = -minLL';    
    for iSubj = subj;
        subjBestPhi(iSubj,:,iModel) = phiRuns(minInd(iSubj),:,iSubj,iModel)';
    end;
    % Nagelkerke 1991 suggest a revised computation of r squared for models
    % whose likelihood is computed from discrete prob distributions (which is the case here)  

    % individ r^2
    maxRSquSubj(:,iModel) = 1 - exp(2*nTrialsSubj.^-1 .* LL0ModelSubj); % upper bound in case LL of model is = 0
    rSquSubj(:,iModel) = 1 - exp(-2./nTrialsSubj .*(LLModelSubj(:,iModel) - LL0ModelSubj));
    rSquCorrSubj(:,iModel) = rSquSubj(:,iModel) ./ maxRSquSubj(:,iModel);

    % individual Bayesian information criterion   
    BIC(:,iModel) = -2.* LLModelSubj(:,iModel) + noPhi(:,iModel) .* log(nTrialsSubj(:,1));

    % AIC
    AIC(:,iModel) = 2* noPhi(:,iModel) - 2 * LLModelSubj(:,iModel);    
    
    try % if uni is down...
        save(parameterPath);
    catch
    end;
    
    
end;
% add BIC and AIC of null model
BIC(:,end+1) = -2.* LL0ModelSubj + noPhi0ModelSubj .* log(nTrialsSubj);
AIC(:,end+1) = 2* noPhi0ModelSubj - 2 * LL0ModelSubj;

save(parameterPath);
x = 10;








