function [ pM_A,pM_V,pC1_givSASV] = computeRespDistrib(pCommon, muP,sigP,sigA,sigV,param);
% computes the multinomidal predicted distribution for auditory and visual counting
% reports (and the binomial distribution for causal judgment which was not queried in the current experiment) given the parameters of the causal
% inference model: by simulating the generative model x times for a given experimental conditions and given parameters, a predicted response distribution is generated
%c.f. Koerding et al (2007)

sSpace = param.sSpace;
iModel = param.iModel;
noSimTrials = param.noSimTrials;
sA = param.sA;
sV = param.sV;
xAPre = param.xAPre;
xVPre = param.xVPre;

noCond = size(sA,1);



%%%%%% generation: draw xA, xV, in dependence on sV, sA and the sigmas by going through generative model


xA = xAPre  .* sigA + sA;
xV = xVPre  .* sigV + sV;

%%%%%%% inference: as reverse process, given drawn xA and xV
% 1. causal inference
% p(xA, xV | C = 1) % C = 1 = common cause
p_xAxVC1 = 1./(2 * pi .*(sigV.^2 .* sigA.^2 + sigV.^2 .* sigP.^2 + sigA.^2.*sigP.^2).^0.5) .*exp(-0.5*(((xV-xA).^2.*sigP.^2 + (xV-muP).^2.*sigA.^2 + (xA-muP).^2.*sigV.^2)...
./(sigV.^2 .* sigA.^2 + sigV.^2 .* sigP.^2 + sigA.^2.*sigP.^2))) ;
% p(xA, xV | C = 2) % C = 2 = seperate cause
p_xAxVC2 = 1./(2.*pi .*((sigV.^2+sigP.^2).*(sigA.^2+sigP.^2)).^0.5) .*exp(-0.5.*((xV-muP).^2 ./(sigV.^2+sigP.^2) + (xA-muP).^2 ./(sigA.^2+sigP.^2)));
% p(C = 1 | xA , xV)

% % forced fusion model 
% pC1 = ones(noCond,noSimTrials);
% pC2 = zeros(noCond,noSimTrials);

pC1 = p_xAxVC1 .* pCommon ./ (p_xAxVC1 .* pCommon + p_xAxVC2 .* (1 - pCommon));
pC2 = 1 - pC1; % p(C = 2 | xA, xV)


%2. location inference %%%%%%%%%%%%%%%%%
% compute MAP of posterior p(sAHat | xA,xV), seperately for common and
% seperate cause (i.e. if pCommon = 1 or pCommon = 0)
% auditory
sHatAC1_MAP = (xV./sigV.^2 + xA./sigA.^2 + muP./sigP.^2) ./ (1./sigV.^2 + 1./sigA.^2 + 1./sigP^2);
sHatAC2_MAP = (xA./sigA.^2+muP/sigP.^2) ./ (1./sigA.^2+1./sigP.^2);
% visual
sHatVC1_MAP = sHatAC1_MAP;
sHatVC2_MAP = (xV./sigV.^2+muP/sigP.^2) ./ (1./sigV.^2+1./sigP.^2);

% mean of posterior p(sHatA | xA,xV) for continous pCommon
if (iModel == 1) || (iModel == 4)  || (iModel == 7);
    sHatA_MAP = (pC1 .* sHatAC1_MAP + pC2 .* sHatAC2_MAP) ;
    sHatV_MAP = (pC1 .* sHatVC1_MAP + pC2 .* sHatVC2_MAP) ;
elseif iModel == 2;
    sHatA_MAP = ((pC1 >= 0.5) .* sHatAC1_MAP + (pC2 > 0.5) .* sHatAC2_MAP) ;
    sHatV_MAP = ((pC1 >= 0.5) .* sHatVC1_MAP + (pC2 > 0.5) .* sHatVC2_MAP) ;
elseif iModel == 3;
    randDec = rand(size(pC1,1),noSimTrials);
    select = (pC1 >= randDec); 
    sHatA_MAP = (select .* sHatAC1_MAP + (1 - select) .* sHatAC2_MAP) ;
    sHatV_MAP = (select .* sHatVC1_MAP + (1 - select) .* sHatVC2_MAP) ;
elseif iModel == 5; % unimodal V
    sHatA_MAP = sHatVC2_MAP;
    sHatV_MAP = sHatVC2_MAP;
elseif iModel == 6;%unimodal A
    sHatA_MAP = sHatAC2_MAP;
    sHatV_MAP = sHatAC2_MAP;    
end;

% generating p(sAHat | sA, sV) as histogramm over 5 response buttons  and p( C =1 | sA, sV) with 2 response buttons by looking at
% p(sAHat | xA, xV) and p(C = 1 | xA, xV) for 10000 simulated xA, xV which
% were generated in dependence on sA, sV

% linking  p(sHatA | xA,xV) to multinomial distrib by finding button which
% is closest to a given sHatA
closestA = abs(repmat(sHatA_MAP,[1,1,4]) - repmat(sSpace,[noCond,noSimTrials,1]));
[c buttonsA] = min(closestA,[],3);
pM_A = [sum(buttonsA == 1,2),sum(buttonsA == 2,2),sum(buttonsA == 3,2),sum(buttonsA == 4,2)];
pM_A = (pM_A + 1) / (noSimTrials + size(pM_A,2));
closestV = abs(repmat(sHatV_MAP,[1,1,4]) - repmat(sSpace,[noCond,noSimTrials,1]));
[c buttonsV] = min(closestV,[],3);
pM_V = [sum(buttonsV == 1,2),sum(buttonsV == 2,2),sum(buttonsV == 3,2),sum(buttonsV == 4,2)];
pM_V = (pM_V + 1) / (noSimTrials + size(pM_V,2));

pC1_givSASV = sum(pC1 > 0.5,2)./noSimTrials; % assumption: if p(C = 1 | xA, xV) > 0.5, model/observer responds unity

